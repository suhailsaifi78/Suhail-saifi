# Mohd Suhail Personal Portfolio

Files:
- index.html
- suhail-hero.jpg
- suhail-about.jpg

Upload all three files to the same GitHub Pages repository and keep the image filenames unchanged.
